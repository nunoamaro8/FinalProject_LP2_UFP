package com.NoWarPolis.City_Classes;

public class Estrada extends Way{

}
