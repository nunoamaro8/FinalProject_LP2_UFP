package com.NoWarPolis.City_Classes;

public class Ciclovia extends Way {
    public Ciclovia(Integer id, User owner) {
        super();

    }
}