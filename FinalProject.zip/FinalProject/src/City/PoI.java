package City;


public class PoI {  //Etiquetas

  public Integer id;

  public Node node;   //Node a que pertence

}