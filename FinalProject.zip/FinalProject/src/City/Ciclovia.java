package City;

public class Ciclovia extends Veiculo {
    public Ciclovia(Integer id, User owner) {
        super(id, owner);
    }
}