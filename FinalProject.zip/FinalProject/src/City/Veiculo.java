package City;



public class Veiculo {

  public Integer id;

    public User owner;

}