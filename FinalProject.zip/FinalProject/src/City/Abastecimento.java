package City;

public class Abastecimento extends PoI {

}