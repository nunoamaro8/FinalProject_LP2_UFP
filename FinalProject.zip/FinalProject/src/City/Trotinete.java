package City;

public class Trotinete extends Veiculo {
    public Trotinete(Integer id, User owner) {
        super(id, owner);
    }
}