package City;

import edu.princeton.cs.algs4.DirectedEdge;
import edu.princeton.cs.algs4.EdgeWeightedDigraph;
import edu.princeton.cs.algs4.ST;

public class DoubleWeightedGraph extends EdgeWeightedDigraph {

    private double weightId;



    public DoubleWeightedGraph(int V) {
        super(V);

    }


    public void passtotime(){
        for(DirectedEdge edge : this.edges()){

        }
    }

    private void time(double distance){
        /*double velocityKMtoMS = this.averageVelocity * 1000;
        velocityKMtoMS /= 3600;
        return (int) (distance/velocityKMtoMS);*/

    }

}
